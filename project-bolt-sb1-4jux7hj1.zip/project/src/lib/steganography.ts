export class StegoShield {
  private static readonly DELIMITER = '|||||';

  static async encryptMessage(message: string, password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(message);
    
    // Generate a key from the password
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );
    
    // Generate a salt
    const salt = window.crypto.getRandomValues(new Uint8Array(16));
    
    // Derive the key
    const key = await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt']
    );
    
    // Generate IV
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    // Encrypt
    const encrypted = await window.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    
    // Combine salt + iv + encrypted data
    const encryptedArray = new Uint8Array(encrypted);
    const combined = new Uint8Array(salt.length + iv.length + encryptedArray.length);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(encryptedArray, salt.length + iv.length);
    
    // Convert to base64 using browser's built-in functions
    return btoa(String.fromCharCode.apply(null, Array.from(combined)));
  }

  static async decryptMessage(encryptedData: string, password: string): Promise<string> {
    // Convert from base64 to Uint8Array
    const binaryStr = atob(encryptedData);
    const combined = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      combined[i] = binaryStr.charCodeAt(i);
    }
    
    const salt = combined.slice(0, 16);
    const iv = combined.slice(16, 28);
    const data = combined.slice(28);
    
    const encoder = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );
    
    const key = await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      true,
      ['decrypt']
    );
    
    const decrypted = await window.crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    
    return new TextDecoder().decode(decrypted);
  }

  static hideMessage(image: HTMLImageElement, message: string): Promise<string> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      canvas.width = image.width;
      canvas.height = image.height;
      ctx.drawImage(image, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      // Convert message to binary
      const messageBinary = message.split('')
        .map(char => char.charCodeAt(0).toString(2).padStart(8, '0'))
        .join('') + this.DELIMITER.split('')
        .map(char => char.charCodeAt(0).toString(2).padStart(8, '0'))
        .join('');
      
      // Hide message in least significant bits
      for (let i = 0; i < messageBinary.length; i++) {
        const pixelIndex = i * 4;
        if (pixelIndex < data.length) {
          data[pixelIndex] = (data[pixelIndex] & 254) | parseInt(messageBinary[i]);
        }
      }
      
      ctx.putImageData(imageData, 0, 0);
      resolve(canvas.toDataURL());
    });
  }

  static extractMessage(image: HTMLImageElement): Promise<string> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      canvas.width = image.width;
      canvas.height = image.height;
      ctx.drawImage(image, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      let binaryMessage = '';
      for (let i = 0; i < data.length; i += 4) {
        binaryMessage += (data[i] & 1).toString();
      }
      
      // Convert binary to text until delimiter is found
      let message = '';
      for (let i = 0; i < binaryMessage.length; i += 8) {
        const byte = binaryMessage.substr(i, 8);
        const char = String.fromCharCode(parseInt(byte, 2));
        message += char;
        
        if (message.endsWith(this.DELIMITER)) {
          message = message.slice(0, -this.DELIMITER.length);
          break;
        }
      }
      
      resolve(message);
    });
  }
}