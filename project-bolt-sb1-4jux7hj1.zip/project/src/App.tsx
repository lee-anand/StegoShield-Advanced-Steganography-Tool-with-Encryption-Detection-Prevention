import React, { useState, useRef } from 'react';
import { Upload, Lock, Unlock, Image as ImageIcon, Download, AlertCircle } from 'lucide-react';
import { StegoShield } from './lib/steganography';

function App() {
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [message, setMessage] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [originalImage, setOriginalImage] = useState<string>('');
  const [processedImage, setProcessedImage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => setOriginalImage(img.src);
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = async () => {
    try {
      setLoading(true);
      setError('');

      if (!originalImage) {
        throw new Error('Please upload an image first');
      }

      if (!message && mode === 'encode') {
        throw new Error('Please enter a message to hide');
      }

      const img = new Image();
      img.src = originalImage;

      if (mode === 'encode') {
        const encryptedMessage = password 
          ? await StegoShield.encryptMessage(message, password)
          : message;
        
        const processedDataUrl = await StegoShield.hideMessage(img, encryptedMessage);
        setProcessedImage(processedDataUrl);
      } else {
        const extractedMessage = await StegoShield.extractMessage(img);
        const decryptedMessage = password 
          ? await StegoShield.decryptMessage(extractedMessage, password)
          : extractedMessage;
        
        setMessage(decryptedMessage);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = processedImage;
    link.download = 'stegoshield-output.png';
    link.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">StegoShield</h1>
          <p className="text-gray-400">Advanced Steganography Tool with Encryption</p>
        </header>

        <div className="max-w-4xl mx-auto bg-gray-800 rounded-xl shadow-2xl overflow-hidden">
          <div className="p-6">
            {/* Mode Toggle */}
            <div className="flex justify-center mb-8">
              <div className="bg-gray-700 p-1 rounded-lg inline-flex">
                <button
                  className={`px-4 py-2 rounded-md transition ${
                    mode === 'encode'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                  onClick={() => setMode('encode')}
                >
                  <Lock className="inline-block w-4 h-4 mr-2" />
                  Encode
                </button>
                <button
                  className={`px-4 py-2 rounded-md transition ${
                    mode === 'decode'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                  onClick={() => setMode('decode')}
                >
                  <Unlock className="inline-block w-4 h-4 mr-2" />
                  Decode
                </button>
              </div>
            </div>

            {/* Image Upload */}
            <div className="mb-6">
              <div
                className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition"
                onClick={() => fileInputRef.current?.click()}
              >
                {originalImage ? (
                  <img
                    src={originalImage}
                    alt="Original"
                    className="max-h-64 mx-auto rounded"
                  />
                ) : (
                  <div className="text-gray-400">
                    <ImageIcon className="w-12 h-12 mx-auto mb-4" />
                    <p>Click to upload an image</p>
                    <p className="text-sm">PNG, JPG up to 5MB</p>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
              </div>
            </div>

            {/* Message Input */}
            <div className="mb-6">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={mode === 'encode' ? "Enter your secret message" : "Decoded message will appear here"}
                className="w-full bg-gray-700 rounded-lg p-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
                readOnly={mode === 'decode'}
              />
            </div>

            {/* Password Input */}
            <div className="mb-6">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Optional encryption password"
                className="w-full bg-gray-700 rounded-lg p-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-6 p-4 bg-red-900/50 rounded-lg flex items-center text-red-200">
                <AlertCircle className="w-5 h-5 mr-2" />
                {error}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={handleProcess}
                disabled={loading}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-3 px-6 flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : mode === 'encode' ? (
                  <>
                    <Upload className="w-5 h-5" />
                    Encode Message
                  </>
                ) : (
                  <>
                    <Unlock className="w-5 h-5" />
                    Decode Message
                  </>
                )}
              </button>

              {processedImage && mode === 'encode' && (
                <button
                  onClick={handleDownload}
                  className="bg-green-600 hover:bg-green-700 text-white rounded-lg py-3 px-6 flex items-center justify-center gap-2 transition"
                >
                  <Download className="w-5 h-5" />
                  Download
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;